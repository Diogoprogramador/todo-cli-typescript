import * as fs from 'fs';
import * as path from 'path';
import { Task, TaskFilter } from './types';

export class TaskManager {
  private tasks: Task[] = [];
  private nextId: number = 1;
  private dataFile: string;

  constructor(dataFile: string = 'tasks.json') {
    this.dataFile = path.join(process.cwd(), dataFile);
    this.loadTasks();
  }

  add(title: string, description?: string): Task {
    const task: Task = {
      id: this.nextId++,
      title,
      description,
      completed: false,
      createdAt: new Date(),
    };
    this.tasks.push(task);
    this.saveTasks();
    return task;
  }

  list(filter: TaskFilter = 'all'): Task[] {
    switch (filter) {
      case 'pending':
        return this.tasks.filter(t => !t.completed);
      case 'completed':
        return this.tasks.filter(t => t.completed);
      default:
        return [...this.tasks];
    }
  }

  complete(id: number): boolean {
    const task = this.tasks.find(t => t.id === id);
    if (!task) return false;
    
    task.completed = true;
    task.completedAt = new Date();
    this.saveTasks();
    return true;
  }

  uncomplete(id: number): boolean {
    const task = this.tasks.find(t => t.id === id);
    if (!task) return false;
    
    task.completed = false;
    task.completedAt = undefined;
    this.saveTasks();
    return true;
  }

  delete(id: number): boolean {
    const index = this.tasks.findIndex(t => t.id === id);
    if (index === -1) return false;
    
    this.tasks.splice(index, 1);
    this.saveTasks();
    return true;
  }

  clear(): void {
    this.tasks = [];
    this.nextId = 1;
    this.saveTasks();
  }

  private loadTasks(): void {
    try {
      if (fs.existsSync(this.dataFile)) {
        const data = fs.readFileSync(this.dataFile, 'utf-8');
        const parsed = JSON.parse(data);
        this.tasks = parsed.tasks.map((t: any) => ({
          ...t,
          createdAt: new Date(t.createdAt),
          completedAt: t.completedAt ? new Date(t.completedAt) : undefined,
        }));
        this.nextId = parsed.nextId || 1;
      }
    } catch (error) {
      console.error('Erro ao carregar tarefas:', error);
      this.tasks = [];
      this.nextId = 1;
    }
  }

  private saveTasks(): void {
    try {
      fs.writeFileSync(this.dataFile, JSON.stringify({
        tasks: this.tasks,
        nextId: this.nextId,
      }, null, 2));
    } catch (error) {
      console.error('Erro ao salvar tarefas:', error);
    }
  }
}

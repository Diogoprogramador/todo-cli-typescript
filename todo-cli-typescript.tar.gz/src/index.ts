#!/usr/bin/env node

import { TaskManager } from './TaskManager';
import { TaskFilter } from './types';

function showHelp(): void {
  console.log(`
📋 Todo CLI - Gerenciador de Tarefas

Uso:
  todo add <titulo> [descricao]     Adicionar nova tarefa
  todo list [filtro]                Listar tarefas (all|pending|completed)
  todo complete <id>                Marcar tarefa como concluída
  todo uncomplete <id>              Desmarcar tarefa
  todo delete <id>                  Remover tarefa
  todo clear                        Remover todas as tarefas
  todo help                         Mostrar ajuda

Exemplos:
  todo add "Comprar leite" "Ir ao mercado"
  todo list pending
  todo complete 1
`);
}

function formatDate(date: Date): string {
  return date.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function main(): void {
  const manager = new TaskManager();
  const args = process.argv.slice(2);
  const command = args[0];

  switch (command) {
    case 'add': {
      const title = args[1];
      const description = args.slice(2).join(' ') || undefined;
      
      if (!title) {
        console.error('❌ Erro: Título é obrigatório');
        process.exit(1);
      }
      
      const task = manager.add(title, description);
      console.log(`✅ Tarefa #${task.id} adicionada: ${task.title}`);
      break;
    }

    case 'list': {
      const filter = (args[1] as TaskFilter) || 'all';
      const tasks = manager.list(filter);
      
      if (tasks.length === 0) {
        console.log('📭 Nenhuma tarefa encontrada');
        break;
      }
      
      console.log(`\n📋 Tarefas (${filter}):\n`);
      tasks.forEach(task => {
        const status = task.completed ? '✅' : '⏳';
        console.log(`${status} #${task.id}: ${task.title}`);
        if (task.description) {
          console.log(`   📝 ${task.description}`);
        }
        console.log(`   📅 Criada: ${formatDate(task.createdAt)}`);
        if (task.completedAt) {
          console.log(`   ✔️ Concluída: ${formatDate(task.completedAt)}`);
        }
        console.log();
      });
      break;
    }

    case 'complete': {
      const id = parseInt(args[1]);
      if (isNaN(id)) {
        console.error('❌ Erro: ID deve ser um número');
        process.exit(1);
      }
      
      if (manager.complete(id)) {
        console.log(`✅ Tarefa #${id} concluída!`);
      } else {
        console.error(`❌ Tarefa #${id} não encontrada`);
        process.exit(1);
      }
      break;
    }

    case 'uncomplete': {
      const id = parseInt(args[1]);
      if (isNaN(id)) {
        console.error('❌ Erro: ID deve ser um número');
        process.exit(1);
      }
      
      if (manager.uncomplete(id)) {
        console.log(`⏳ Tarefa #${id} desmarcada`);
      } else {
        console.error(`❌ Tarefa #${id} não encontrada`);
        process.exit(1);
      }
      break;
    }

    case 'delete': {
      const id = parseInt(args[1]);
      if (isNaN(id)) {
        console.error('❌ Erro: ID deve ser um número');
        process.exit(1);
      }
      
      if (manager.delete(id)) {
        console.log(`🗑️ Tarefa #${id} removida`);
      } else {
        console.error(`❌ Tarefa #${id} não encontrada`);
        process.exit(1);
      }
      break;
    }

    case 'clear': {
      manager.clear();
      console.log('🧹 Todas as tarefas foram removidas');
      break;
    }

    case 'help':
    case undefined:
    default:
      showHelp();
      break;
  }
}

main();
